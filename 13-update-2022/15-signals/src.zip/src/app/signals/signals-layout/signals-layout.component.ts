import { Component } from '@angular/core';

@Component({
  selector: 'app-signals-layout',
  standalone: true,
  imports: [],
  templateUrl: './signals-layout.component.html',
  styleUrl: './signals-layout.component.css'
})
export class SignalsLayoutComponent {

}
